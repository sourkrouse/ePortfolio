package com.zybooks.weighttracker.data;

public class DbConfig {
    public static final String ROOM_DB_NAME = "app_database";
    public static final String USER_TABLE = "user_table";
    public static final String REGISTER_TABLE = "registration_table";
    public static final String WEIGHTS_TABLE = "weights_table";

}
